﻿namespace CurrencyManagement.Models
{
    public interface ICurrencyService
    {
        IEnumerable<Currency> GetCurrencies();
        void CreateCurrency(Currency currency);
        Currency GetCurrency(int id);
        void UpdateCurrency(int id, Currency currency);
        void DeleteCurrency(int id);
    }
}

