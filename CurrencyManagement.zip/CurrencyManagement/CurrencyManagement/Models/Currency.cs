﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CurrencyManagement.Models
{
    public partial class Currency
    {
        [Required(ErrorMessage = "Name is mandatory")]
        [MinLength(2)]
        public string Name { get; set; } = null!;

        [Required(ErrorMessage = "Code is mandatory")]
        [MinLength(1)]
        public string Code { get; set; } = null!;
        public int Id { get; set; }
    }
}
