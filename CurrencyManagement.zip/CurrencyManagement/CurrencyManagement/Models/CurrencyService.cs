﻿using Microsoft.EntityFrameworkCore;

namespace CurrencyManagement.Models
{
    public class CurrencyService : ICurrencyService
    {
        private ASGContext _context;
        public CurrencyService(ASGContext context)
        {
            _context = context;
        }

        public void DeleteCurrency(int id)
        {
            try
            {
                Currency? currency = _context.Currencies.Find(id);
                if (currency != null)
                {
                    _context.Currencies.Remove(currency);
                }
                _context.SaveChanges();
            }
            catch
            {
                throw;
            }
        }
        public Currency GetCurrency(int id)
        {
            try
            {
                Currency? currency = _context.Currencies.Find(id);
                if (currency != null)
                {
                    return currency;
                }
                else
                {
                    throw new ArgumentNullException();
                }
            }
            catch
            {
                throw;
            }
        }
        public IEnumerable<Currency> GetCurrencies()
        {
            try
            {
                return _context.Currencies.ToList();
            }
            catch
            {
                throw;
            }
        }

        public void CreateCurrency(Currency currency)
        {
            try
            {
                _context.Currencies.Add(currency);
                _context.SaveChanges();
            }
            catch
            {
                throw;
            }
        }
        public void UpdateCurrency(int id, Currency currency)
        {
            try
            {
                var local = _context.Set<Currency>().Local.FirstOrDefault(entry => entry.Id.Equals(currency.Id));
                if (local != null)
                {
                    _context.Entry(local).State = EntityState.Detached;
                }
                _context.Entry(currency).State = EntityState.Modified;
                _context.SaveChanges();
            }
            catch
            {
                throw;
            }
        }
    }
}
